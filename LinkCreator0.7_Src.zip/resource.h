//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ ���ɵİ����ļ���
// �� LinkCreator.rc ʹ��
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_LINKCREATOR                 100
#define IDS_STRING101                   101
#define IDD_LINKCREATOR_DIALOG          102
#define IDP_SOCKETS_INIT_FAILED         103
#define IDR_MAINFRAME                   128
#define IDC_FILEPATH                    1000
#define IDS_FILELOCATION                1000
#define IDC_BROWSE                      1001
#define IDS_BROWSE                      1001
#define IDC_HTTPLIST                    1002
#define IDS_ADDHTTP                     1002
#define IDC_HTTPPATH                    1003
#define IDS_HTTPREMOVE                  1003
#define IDC_ADDHTTP                     1004
#define IDS_HTTPADDRESS                 1004
#define IDC_HTTPREMOVE                  1005
#define IDS_ADDEDHTTPSOURCES            1005
#define IDC_HTTPCLEAR                   1006
#define IDS_HTTPCLEAR                   1006
#define IDC_RESULT                      1007
#define IDS_ED2KLINK                    1007
#define IDC_START                       1008
#define IDS_START                       1008
#define IDC_CANCEL                      1009
#define IDS_CANCEL                      1009
#define IDC_EXIT                        1010
#define IDS_EXIT                        1010
#define IDC_WITHHASHSET                 1011
#define IDS_WITHHASHSET                 1011
#define IDC_PROGRESS1                   1012
#define IDS_EX1                         1012
#define IDS_EX2                         1013
#define IDC_COPY2CB                     1013
#define IDC_WITHAICH                    1014
#define IDS_COPYTOCLIPBOARD             1014
#define IDC_STATIC1                     1015
#define IDS_WITHAICH                    1015
#define IDC_STATIC2                     1016
#define IDS_COPYRIGHTS                  1016
#define IDC_STATIC3                     1017
#define IDS_TRANSLATION                 1017
#define IDC_STATIC4                     1018
#define IDS_ABOUT                       1018
#define IDC_STATIC5                     1019
#define IDS_OK                          1019
#define IDC_STATIC6                     1020
#define IDS_HASHING                     1020
#define IDS_INVALIDFILEPATH             1021
#define IDC_LANGCOMBO                   1021
#define IDS_INVALIDURL                  1022
#define IDC_CLIENTSOURCESLIST           1022
#define IDS_CANTOPENFILE                1023
#define IDC_SOURCESFRAME                1023
#define IDS_CANTCREATEAICH              1024
#define IDC_CLIENTSOURCE                1024
#define IDS_SOURCESMANAGEMENT           1025
#define IDC_ADDCLIENT                   1025
#define IDS_CLIENTSCOURCE               1026
#define IDC_CHECKSOURCE                 1026
#define IDC_STATICCLIENTSOURCES         1027
#define IDS_CLIENTSOURCESLIST           1027
#define IDS_ERRCLIENTSOURCE             1028
#define IDC_STATUS                      1028
#define IDC_STATIC8                     1029
#define IDS_CHECKSOURCE                 1029
#define IDC_CLIENTREMOVE                1030
#define IDS_ERR_WEBSOURCECHECK          1030
#define IDC_CLIENTSOURCECLEAR           1031
#define IDS_ERR_WEBSOURCECHECK_NOMATCH  1031
#define IDS_FILETOOLARGE                1032
#define IDC_STATIC7                     1032
#define IDC_LENGTHCHECK                 1033
#define IDS_LENGTHCHECK                 1034
#define IDC_SHUTDOWN                    1035

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1036
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
